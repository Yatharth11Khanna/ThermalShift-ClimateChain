# ThermalShift — ClimateChain 2026 MVP foundation

ThermalShift is a software-only prototype for carbon-aware cold-storage scheduling. It compares a baseline cooling profile with an optimized schedule under a simplified temperature-state model, then creates a SHA-256 evidence fingerprint for the report.

## Important prototype boundaries
- Demo inputs are synthetic and do not represent a real facility or live grid data.
- The thermal model is deliberately simple and is not a validated refrigeration or food-safety model.
- The hash is generated locally. No blockchain transaction is submitted in this initial scaffold.
- Do not use this prototype to control real refrigeration equipment or make food-safety decisions.

## Project structure
- `frontend/` — React + Vite dashboard
- `backend/` — FastAPI API and SciPy linear optimization model

## Run locally

### Backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### Frontend
In another terminal:
```bash
cd frontend
npm install
npm run dev
```

Set `VITE_API_BASE=http://localhost:8000` in `frontend/.env.local` if the frontend is served on a different origin. Vite's default development server runs on port 5173.

## Replit note
For the first Replit iteration, import the project and run the backend and frontend as separate workflows/services. Once the core calculations are validated, consolidate the run/deploy configuration for the chosen Replit deployment mode.

## API
- `GET /api/health`
- `GET /api/demo`
- `POST /api/optimize` with `{ "scenario": { ... } }`
- `POST /api/verify-hash` with `{ "report": { ... }, "report_hash": "..." }`

## Next implementation milestones
1. Add CSV import with schema validation and clear units.
2. Validate baseline and optimized temperature trajectories and improve the thermal model.
3. Add sourced, time-stamped tariff and grid-emissions inputs or label all data synthetic.
4. Add testnet anchoring of evidence hashes, storing transaction ID and explorer URL.
5. Add reproducible evaluation cases and tests for infeasible schedules, missing data, and constraint violations.
