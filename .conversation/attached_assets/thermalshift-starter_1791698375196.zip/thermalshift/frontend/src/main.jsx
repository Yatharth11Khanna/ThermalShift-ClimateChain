import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Activity, ArrowDownRight, ArrowUpRight, Check, ChevronDown, CircleHelp, Cloud, Download, FileCheck2, Leaf, LockKeyhole, Play, ShieldCheck, Snowflake, Thermometer, Zap } from 'lucide-react';
import './styles.css';

const API = import.meta.env.VITE_API_BASE || '';
const fmt = (v, d=1) => Number(v ?? 0).toLocaleString(undefined, {maximumFractionDigits:d, minimumFractionDigits:d});
const money = (v) => '₹' + Number(v ?? 0).toLocaleString('en-IN', {maximumFractionDigits:2});

function App() {
  const [scenario, setScenario] = useState(null);
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [optimizing, setOptimizing] = useState(false);
  const [error, setError] = useState('');
  const [view, setView] = useState('overview');
  const [activeHour, setActiveHour] = useState(14);
  const [weights, setWeights] = useState({cost: 50, carbon: 50});
  const [verify, setVerify] = useState(null);

  useEffect(() => { fetch(`${API}/api/demo`).then(r => { if(!r.ok) throw new Error('API unavailable'); return r.json(); }).then(s => {setScenario(s); setLoading(false);}).catch(() => { setError('Could not connect to the optimization API. Start the backend service and refresh.'); setLoading(false); }); }, []);

  const runOptimize = async () => {
    if (!scenario) return;
    setOptimizing(true); setError(''); setVerify(null);
    try {
      const payload = {...scenario, cost_weight: weights.cost/100, carbon_weight: weights.carbon/100};
      const res = await fetch(`${API}/api/optimize`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({scenario:payload})});
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Optimization failed');
      if (!data.feasible) throw new Error(data.message || 'No safe schedule found');
      setReport(data); setView('overview');
    } catch(e) { setError(e.message || 'Could not optimize this scenario.'); }
    finally { setOptimizing(false); }
  };

  useEffect(() => { if(scenario && !report) runOptimize(); }, [scenario]);

  const chartData = report?.hourly || [];
  const metricCards = report ? [
    {label:'Estimated emissions', value:fmt(report.optimized.emissions_kgco2,1)+' kg', change:fmt(report.change_pct.emissions_reduction_pct,1)+'%', icon:Leaf, tone:'green', note:'vs. baseline'},
    {label:'Energy cost', value:money(report.optimized.cost), change:fmt(report.change_pct.cost_reduction_pct,1)+'%', icon:Zap, tone:'blue', note:'vs. baseline'},
    {label:'Energy consumed', value:fmt(report.optimized.energy_kwh,1)+' kWh', change:fmt(report.change_pct.energy_reduction_pct,1)+'%', icon:Activity, tone:'violet', note:'vs. baseline'},
    {label:'Peak load proxy', value:fmt(report.optimized.peak_kw_proxy,2)+' kW', change:fmt(report.change_pct.peak_reduction_pct,1)+'%', icon:Cloud, tone:'amber', note:'vs. baseline'},
  ] : [];

  const downloadReport = () => {
    if(!report) return;
    const blob = new Blob([JSON.stringify(report, null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href=url; a.download='thermalshift-evidence-report.json'; a.click(); URL.revokeObjectURL(url);
  };
  const verifyReport = async () => {
    if(!report) return;
    try { const res = await fetch(`${API}/api/verify-hash`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({report: Object.fromEntries(Object.entries(report).filter(([k])=>k!=='evidence')), report_hash: report.evidence.report_hash})}); const data = await res.json(); setVerify(data); }
    catch { setVerify({valid:false,note:'Could not contact verification API.'}); }
  };

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Snowflake size={22}/></div><div><div className="brand-name">thermal<span>shift</span></div><div className="brand-caption">ENERGY INTELLIGENCE</div></div></div>
      <div className="workspace"><div className="workspace-dot"/><div><b>Demo cold store</b><small>Facility workspace</small></div><ChevronDown size={15}/></div>
      <div className="nav-label">WORKSPACE</div>
      <button className={`nav-item ${view==='overview'?'active':''}`} onClick={()=>setView('overview')}><Activity size={17}/> Overview</button>
      <button className={`nav-item ${view==='schedule'?'active':''}`} onClick={()=>setView('schedule')}><Snowflake size={17}/> Cooling schedule</button>
      <button className={`nav-item ${view==='evidence'?'active':''}`} onClick={()=>setView('evidence')}><FileCheck2 size={17}/> Evidence & audit</button>
      <div className="sidebar-bottom"><div className="status-card"><div className="status-top"><span className="status-pulse"/> SYSTEM STATUS</div><b>Optimization engine ready</b><small>Prototype environment · v0.1</small></div><div className="profile"><div className="avatar">TS</div><div><b>ThermalShift Lab</b><small>ClimateChain 2026</small></div><CircleHelp size={17}/></div></div>
    </aside>
    <main className="main-content">
      <header className="topbar"><div className="breadcrumbs">Workspace <span>/</span> <b>{view==='overview'?'Overview':view==='schedule'?'Cooling schedule':'Evidence & audit'}</b></div><div className="top-actions"><div className="demo-pill"><span/> SIMULATED DATA</div><button className="icon-button" title="Help"><CircleHelp size={18}/></button><div className="top-avatar">TS</div></div></header>
      <div className="page-wrap">
        <section className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> CARBON-AWARE COLD STORAGE</div><h1>{view==='overview'?'Make every cooling hour count.':view==='schedule'?'A smarter cooling schedule.':'Evidence you can independently verify.'}</h1><p>{view==='overview'?'Shift flexible refrigeration demand toward cleaner, lower-cost hours—without crossing configured temperature limits.':view==='schedule'?'Compare the current operating profile with a temperature-constrained optimized schedule.':'Review the assumptions, results and cryptographic fingerprint behind this simulation.'}</p></div><button className="primary-button" onClick={runOptimize} disabled={!scenario||optimizing}><Play size={16} fill="currentColor"/>{optimizing?'Optimizing…':'Run optimization'}</button></section>
        {error && <div className="error-banner">{error}</div>}
        <div className="notice"><div className="notice-icon"><CircleHelp size={17}/></div><div><b>Research prototype, not live facility control.</b><span>Demo inputs are synthetic. The thermal model is simplified and must be validated against real equipment and food-safety requirements before operational use.</span></div><button onClick={()=>setError('The current demo uses synthetic 24-hour data and an illustrative linear thermal model. No live equipment is connected.')}>Learn more</button></div>
        {view==='overview' && <>
          <section className="metric-grid">{metricCards.map((m,i)=><div className="metric-card" key={m.label}><div className="metric-head"><span>{m.label}</span><div className={`metric-icon ${m.tone}`}><m.icon size={18}/></div></div><div className="metric-value">{report?m.value:'—'}</div><div className="metric-foot"><span className={`change ${Number(report?.change_pct?.[i===0?'emissions_reduction_pct':i===1?'cost_reduction_pct':i===2?'energy_reduction_pct':'peak_reduction_pct'])>=0?'positive':'negative'}`}>{Number(report?.change_pct?.[i===0?'emissions_reduction_pct':i===1?'cost_reduction_pct':i===2?'energy_reduction_pct':'peak_reduction_pct'])>=0?<ArrowDownRight size={14}/>:<ArrowUpRight size={14}/>} {m.change}</span><span>{m.note}</span></div></div>)}</section>
          <section className="content-grid"><div className="panel chart-panel"><div className="panel-heading"><div><h2>Cooling load profile</h2><p>Baseline vs. optimized hourly electricity use</p></div><div className="legend"><span><i className="legend-baseline"/> Baseline</span><span><i className="legend-optimized"/> Optimized</span></div></div><div className="chart-area">{report?<ResponsiveContainer width="100%" height="100%"><AreaChart data={chartData} margin={{top:10,right:8,left:-15,bottom:0}}><defs><linearGradient id="optimizedFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#2dd4a7" stopOpacity={0.22}/><stop offset="100%" stopColor="#2dd4a7" stopOpacity={0.01}/></linearGradient></defs><CartesianGrid strokeDasharray="3 5" stroke="#243943" vertical={false}/><XAxis dataKey="hour" tickFormatter={h=>`${String(h).padStart(2,'0')}:00`} tick={{fill:'#8296a0',fontSize:10}} axisLine={false} tickLine={false} interval={3}/><YAxis tick={{fill:'#8296a0',fontSize:10}} axisLine={false} tickLine={false}/><Tooltip contentStyle={{background:'#102630',border:'1px solid #29414b',borderRadius:10,color:'#eaf2f4'}} labelFormatter={h=>`${String(h).padStart(2,'0')}:00`} formatter={(v,n)=>[`${Number(v).toFixed(3)} kWh`,n]}/><Area type="monotone" dataKey="baseline_kwh" name="Baseline" stroke="#728994" strokeWidth={2} strokeDasharray="5 4" fill="transparent"/><Area type="monotone" dataKey="optimized_kwh" name="Optimized" stroke="#2dd4a7" strokeWidth={2.5} fill="url(#optimizedFill)"/></AreaChart></ResponsiveContainer>:<div className="empty-chart">{loading?'Loading demo data…':'Run optimization to see results'}</div>}</div><div className="chart-footer"><span><i className="tiny-dot green-dot"/> Schedule optimized across 24 hours</span><span>Hourly intervals · Illustrative model</span></div></div>
          <div className="panel temperature-panel"><div className="panel-heading"><div><h2>Temperature guardrails</h2><p>Configured product-temperature limits</p></div><div className="temp-icon"><Thermometer size={19}/></div></div><div className="temp-range"><div><span>MINIMUM</span><b>{scenario?.min_temp_c ?? 1}°C</b></div><div className="range-track"><div className="range-safe"/><div className="range-marker" style={{left:'51%'}}/></div><div><span>MAXIMUM</span><b>{scenario?.max_temp_c ?? 5}°C</b></div></div><div className="temp-readings"><div className="reading"><span>Lowest simulated</span><b>{report?fmt(report.temperature_check.min_c,2)+'°C':'—'}</b></div><div className="reading"><span>Highest simulated</span><b>{report?fmt(report.temperature_check.max_c,2)+'°C':'—'}</b></div></div><div className={`safety-status ${report?.temperature_check.within_configured_limits?'safe':'warning'}`}><ShieldCheck size={17}/><div><b>{report?.temperature_check.within_configured_limits?'Configured limits respected':'Check temperature constraints'}</b><small>{report?'Based on the simplified model—not a food-safety certification.':'Waiting for optimization result.'}</small></div></div><div className="mini-note">Model assumption: each kWh of cooling reduces simulated temperature by a fixed coefficient.</div></div></section>
          <section className="bottom-grid"><div className="panel schedule-panel"><div className="panel-heading"><div><h2>Hourly schedule</h2><p>Select an hour to inspect the operating decision</p></div><button className="text-button" onClick={()=>setView('schedule')}>Full schedule <ArrowUpRight size={14}/></button></div><div className="hour-strip">{Array.from({length:24},(_,i)=><button key={i} onClick={()=>setActiveHour(i)} className={`hour-cell ${i===activeHour?'selected':''} ${report&&report.hourly[i].optimized_kwh<report.hourly[i].baseline_kwh-.05?'reduced':report&&report.hourly[i].optimized_kwh>report.hourly[i].baseline_kwh+.05?'increased':''}`}><span>{String(i).padStart(2,'0')}</span><i/></button>)}</div><div className="selected-hour"><div><span>SELECTED HOUR</span><b>{String(activeHour).padStart(2,'0')}:00 – {String((activeHour+1)%24).padStart(2,'0')}:00</b></div><div><span>BASELINE</span><b>{report?fmt(report.hourly[activeHour].baseline_kwh,2)+' kWh':'—'}</b></div><div><span>OPTIMIZED</span><b className="mint-text">{report?fmt(report.hourly[activeHour].optimized_kwh,2)+' kWh':'—'}</b></div></div></div><div className="panel evidence-card"><div className="evidence-symbol"><LockKeyhole size={21}/></div><div className="evidence-copy"><h2>Evidence integrity</h2><p>Every run generates a SHA-256 fingerprint for its result. Blockchain anchoring is the next integration step.</p><div className="evidence-state"><span className="status-pulse"/> {report?'Local hash generated':'Awaiting report'}</div></div><button className="outline-button" onClick={()=>setView('evidence')}>Inspect evidence</button></div></section>
        </>}
        {view==='schedule' && <section className="panel full-panel"><div className="panel-heading"><div><h2>24-hour cooling plan</h2><p>Optimized consumption, tariff, carbon intensity, and temperature state</p></div><button className="outline-button" onClick={downloadReport}><Download size={15}/> Export report</button></div><div className="table-wrap"><table><thead><tr><th>Hour</th><th>Baseline kWh</th><th>Optimized kWh</th><th>Tariff (₹/kWh)</th><th>Grid intensity (kg CO₂/kWh)</th><th>Simulated temp.</th></tr></thead><tbody>{chartData.map(r=><tr key={r.hour}><td>{String(r.hour).padStart(2,'0')}:00</td><td>{fmt(r.baseline_kwh,3)}</td><td className="mint-text">{fmt(r.optimized_kwh,3)}</td><td>{fmt(r.tariff,2)}</td><td>{fmt(r.grid_kgco2_per_kwh,3)}</td><td>{fmt(r.optimized_temp_c,2)}°C</td></tr>)}</tbody></table></div></section>}
        {view==='evidence' && <section className="evidence-layout"><div className="panel full-panel"><div className="panel-heading"><div><h2>Evidence record</h2><p>Reproducibility and tamper-evidence for this optimization run</p></div><div className="hash-chip"><LockKeyhole size={14}/> SHA-256</div></div><div className="evidence-block"><span>REPORT FINGERPRINT</span><code>{report?.evidence.report_hash || 'Run optimization to generate a report hash'}</code><button className="outline-button" onClick={()=>report&&navigator.clipboard?.writeText(report.evidence.report_hash)}>Copy hash</button></div><div className="integrity-row"><div className="integrity-icon"><ShieldCheck size={20}/></div><div><b>Local integrity fingerprint generated</b><p>The hash helps detect changes to the report content. It does not validate the truth of the source meter readings.</p></div></div><div className="chain-placeholder"><div className="chain-icon"><LockKeyhole size={20}/></div><div><b>Blockchain anchoring · Planned integration</b><p>Next: submit the report hash to a supported public testnet and retain the transaction ID and explorer link. No transaction has been submitted yet.</p></div><span className="planned-tag">NOT CONNECTED</span></div><div className="evidence-actions"><button className="primary-button" onClick={downloadReport} disabled={!report}><Download size={16}/> Download evidence JSON</button><button className="outline-button" onClick={verifyReport} disabled={!report}><ShieldCheck size={16}/> Verify report integrity</button></div>{verify&&<div className={`verify-result ${verify.valid?'valid':'invalid'}`}><b>{verify.valid?'Integrity check passed':'Integrity check failed'}</b><p>{verify.note || 'The supplied report fingerprint was compared with a freshly calculated hash.'}</p></div>}<p className="model-disclaimer">This prototype is for research and demonstration. It is not a validated refrigeration controller, food-safety certification, financial settlement system, or proof of independently measured carbon savings.</p></div></section>}
        <footer><div><Snowflake size={15}/> <b>THERMALSHIFT</b><span>Built for IEEE ClimateChain 2026</span></div><span>Prototype v0.1.0 <i/> Synthetic demo data</span></footer>
      </div>
    </main>
  </div>;
}

createRoot(document.getElementById('root')).render(<App/>);
