# Replit Agent instructions

You are continuing an existing ThermalShift codebase. Do not replace the application with a generic landing page or rewrite the optimization engine without explaining why.

## First setup task
1. Inspect the project structure and README.
2. Install backend dependencies from `backend/requirements.txt`.
3. Install frontend dependencies from `frontend/package.json`.
4. Configure Replit so the FastAPI backend runs on port 8000 and the Vite frontend runs on a public web port, with both processes visible/restartable.
5. Preserve the Vite `/api` proxy to `http://127.0.0.1:8000` for development.
6. Test `GET /api/health`, `GET /api/demo`, and `POST /api/optimize`.
7. Open the UI and confirm the dashboard renders and the optimization request succeeds.
8. Fix only setup/runtime issues found. Keep the synthetic-data and simplified-model warnings visible.

## Product guardrails
- This is a software-only prototype for a hackathon, not live refrigeration control.
- Do not claim simulated savings are measured real-world savings.
- Do not claim a blockchain transaction exists until a real testnet transaction is implemented and its transaction ID is displayed.
- Do not remove temperature constraints or the equality constraint preserving the total baseline cooling-energy budget.
- Do not add fake integrations, fake data provenance, or fake verification badges.

## Next feature after setup is working
Implement CSV upload with schema validation for 24 hourly rows. Required columns: `hour`, `baseline_kwh`, `tariff_per_kwh`, `grid_kgco2_per_kwh`, `ambient_heat_gain_c`. Keep the demo scenario available. Show validation errors in the UI and label user-uploaded data as user-provided, not externally verified. Add tests for malformed CSV, negative values, infeasible constraints, and report-hash verification.
